<table width="100%" class="tborder" >

      <tr>
        <td align="left" colspan="2" class="admin"> Mini Stats... </td>
      </tr>
      <tr>
        <td width="100"> Total Gallery : </td>
        <td align="left"  class="admin"><?php echo $gallery; ?></td>
      </tr>
      <tr>
        <td> Total Album : </td>
        <td align="left"  class="admin"><?php echo $album; ?></td>
      </tr>
      <tr>
        <td> Total Picture : </td>
        <td align="left"  class="admin"><?php echo $picture; ?></td>
      </tr>	  	  
    </table>